import { drizzle } from "drizzle-orm/neon-serverless";
import ws from "ws";
import * as schema from "@db/schema";

const databaseUrl = process.env.DATABASE_URL || "sqlite://default.db"; // Replace with a fallback DB

if (!process.env.DATABASE_URL) {
    console.warn("Warning: DATABASE_URL is not set. Using default database.");
}

// Use `databaseUrl` in your database connection logic


export const db = drizzle({
  connection: process.env.DATABASE_URL,
  schema,
  ws: ws,
});
