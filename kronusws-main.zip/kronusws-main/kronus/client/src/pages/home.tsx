import { Helmet } from "react-helmet";
import Nav from "@/components/navigation/nav";
import Hero from "@/components/sections/hero";
import Screenshot from "@/components/sections/screenshot";
import Features from "@/components/sections/features";
import DownloadSection from "@/components/sections/download";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <div className="min-h-screen bg-black text-white overflow-hidden">
      <Helmet>
        <title>Kronus | Future of Execution</title>
        <meta name="description" content="Everyone's using Kronus. And you aren't?" />
      </Helmet>

      <div className="fixed w-full h-full bg-gradient-to-br from-black via-background to-primary/10" />
      <div className="fixed w-full h-full">
        <div className="absolute inset-0 bg-[url('/grid.svg')] bg-center [mask-image:linear-gradient(180deg,white,rgba(255,255,255,0))]" />
        <div className="absolute w-full h-full bg-black [background:radial-gradient(125%_125%_at_50%_10%,#000_40%,#3366cc_100%)]" />
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="relative"
      >
        <Nav />
        <main className="container mx-auto px-4 space-y-24 pb-32">
          <Hero />
          <Screenshot />
          <Features />
          <DownloadSection />
        </main>
      </motion.div>
    </div>
  );
}
