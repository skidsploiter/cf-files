import { motion } from "framer-motion";

export default function Screenshot() {
  return (
    <section className="relative py-16 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="max-w-6xl mx-auto"
      >
        <div className="relative aspect-[16/9] rounded-xl overflow-hidden bg-black/50 backdrop-blur-sm border border-border/30">
          <svg
            className="absolute inset-0 w-full h-full"
            viewBox="0 0 1200 675"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Window chrome */}
            <rect x="0" y="0" width="1200" height="32" fill="hsl(var(--card))" opacity="0.4" />
            <circle cx="20" cy="16" r="6" fill="#ff5f57" />
            <circle cx="40" cy="16" r="6" fill="#febc2e" />
            <circle cx="60" cy="16" r="6" fill="#28c840" />

            {/* Script list */}
            <rect x="0" y="32" width="240" height="643" fill="hsl(var(--card))" opacity="0.2" />
            {[0, 1, 2, 3, 4].map((i) => (
              <rect
                key={i}
                x="12"
                y={48 + i * 36}
                width="216"
                height="28"
                rx="4"
                fill="hsl(var(--muted))"
                opacity={i === 0 ? 0.3 : 0.15}
              />
            ))}

            {/* Main editor area */}
            <rect x="252" y="44" width="936" height="619" rx="4" fill="hsl(var(--card))" opacity="0.2" />

            {/* Code lines */}
            {Array.from({ length: 15 }).map((_, i) => (
              <rect
                key={i}
                x="264"
                y={60 + i * 24}
                width={Math.random() * 400 + 200}
                height="12"
                rx="2"
                fill="hsl(var(--primary))"
                opacity={0.2 - (i * 0.01)}
              />
            ))}

            {/* Execute button */}
            <rect x="264" y="600" width="120" height="36" rx="4" fill="hsl(var(--primary))" opacity="0.4" />
            <rect x="400" y="600" width="120" height="36" rx="4" fill="hsl(var(--muted))" opacity="0.2" />

            {/* Status bar */}
            <rect x="0" y="655" width="1200" height="20" fill="hsl(var(--card))" opacity="0.3" />
            <rect x="8" y="659" width="100" height="12" rx="2" fill="hsl(var(--primary))" opacity="0.4" />
          </svg>
        </div>
      </motion.div>
    </section>
  );
}