import { motion } from "framer-motion";
import { Shield, Zap, Code, Cpu, ArrowUpRight } from "lucide-react";

const features = [
  {
    icon: Shield,
    title: "Fast & Secure",
    description: "Advanced protection system ensures your safety while scripting. Regular updates to stay ahead."
  },
  {
    icon: Zap,
    title: "Lightning Fast Execution",
    description: "Optimized execution engine for instant script loading and running with minimal latency."
  },
  {
    icon: Code,
    title: "Advanced API",
    description: "Full Lua API implementation with custom functions and libraries for maximum compatibility."
  },
  {
    icon: Cpu,
    title: "Stable Performance",
    description: "Built with stability in mind, ensuring smooth operation even with complex scripts."
  }
];

export default function Features() {
  return (
    <section id="features" className="relative py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="grid md:grid-cols-2 gap-8"
      >
        {features.map((feature, index) => (
          <div
            key={index}
            className="group p-8 bg-card/20 backdrop-blur-sm rounded-lg border border-border/50 hover:border-primary/50 transition-colors"
          >
            <feature.icon className="h-8 w-8 mb-4 text-primary" />
            <h3 className="text-xl font-semibold mb-2 flex items-center gap-2">
              {feature.title}
              <ArrowUpRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
            </h3>
            <p className="text-muted-foreground">{feature.description}</p>
          </div>
        ))}
      </motion.div>
    </section>
  );
}