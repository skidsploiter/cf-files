import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Download as DownloadIcon, Shield, Monitor } from "lucide-react";

export default function DownloadSection() {
  const handleDownload = () => {
    // TODO: Add download functionality (fn js red to dc)
    window.open('https://discord.gg/X9sp3psXrp', '_self');
  };

  return (
    <section id="download" className="relative">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
        className="max-w-4xl mx-auto text-center space-y-8"
      >
        <h2 className="text-3xl md:text-5xl font-bold tracking-tight">
          Want to feel the power?
        </h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Download Kronus now and join hundreds of satisfied users. Regular updates and dedicated support included.
        </p>

        <div className="flex flex-col items-center gap-6">
          <Button size="lg" onClick={handleDownload} className="bg-primary hover:bg-primary/90">
            <DownloadIcon className="mr-2 h-5 w-5" />
            Download Now (Free)
          </Button>

          <div className="flex items-center gap-8 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              <span>No Malware/RAT</span>
            </div>
            <div className="flex items-center gap-2">
              <Monitor className="h-4 w-4" />
              <span>Windows 10/11</span>
            </div>
          </div>
        </div>
      </motion.div>
    </section>
  );
}
